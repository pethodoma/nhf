#include "struktura.h"

#ifndef NHF_L_FAJLKEZ_H
#define NHF_L_FAJLKEZ_H
void fajlbair(Esemeny *head);
#endif //NHF_L_FAJLKEZ_H

#include "struktura.h"
#include <stdbool.h>

#ifndef NHF_L_SEGEDFUGGVENYEK_H
#define NHF_L_SEGEDFUGGVENYEK_H
bool rendeznikell(Esemeny *egyik,Esemeny *masik);
void *beolvas(char *asd);
bool vane(Esemeny *eleje,char *vmi);
Esemeny *eldont(Esemeny *head,Esemeny **e);
bool vaneho(Esemeny *head,int evbe,int hobe);
bool vanenap(Esemeny *head,int evbe,int hobe,int napbe);
bool egyezik(Esemeny *egyik,Esemeny *masik);
#endif //NHF_L_SEGEDFUGGVENYEK_H

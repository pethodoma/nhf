#include "segedfuggvenyek.h"
#include "struktura.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "fofuggvenyek.h"
bool rendeznikell(Esemeny *egyik,Esemeny *masik){
    if(egyik->ev<masik->ev || egyik->ev==masik->ev && egyik->honap<masik->honap || egyik->ev==masik->ev && egyik->honap==masik->honap && egyik->nap<masik->nap)
        return true;
    return false;
}
void *beolvas(char *hova){
    int c=0;
    char k;
    do{
        k=getchar();
        hova[c]=k;
        c++;

    }while(k!='\n');
    c=c-1;
    hova[c]='\0';
}

bool vane(Esemeny *eleje,char *szoveg){
    Esemeny *temp=eleje;
    for(temp;temp!=NULL;temp=temp->kovetkezo)
        if(strcmp(szoveg,temp->nev)==0)
            return true;
    return false;
}
Esemeny *eldont(Esemeny *eleje,Esemeny **e) {
    *e = keres(eleje);
    if (*e == NULL)
        return NULL;
    else
        return *e;
}
bool vaneho(Esemeny *head,int evbe,int hobe){
    Esemeny *mozgo=head;
    for(mozgo;mozgo!=NULL;mozgo=mozgo->kovetkezo)
        if(mozgo->ev==evbe && mozgo->honap==hobe)
            return true;
    return false;
}
bool vanenap(Esemeny *eleje,int evbe,int hobe,int napbe){
    Esemeny *mozgo=eleje;
    for(mozgo;mozgo!=NULL;mozgo=mozgo->kovetkezo)
        if(mozgo->ev==evbe && mozgo->honap==hobe && mozgo->nap==napbe)
            return true;
    return false;

}
bool egyezik(Esemeny *egyik,Esemeny *masik){
    if(egyik->ev==masik->ev && egyik->honap==masik->honap ==egyik->nap==masik->nap && strcmp(egyik->nev,masik->nev)==0)
        return true;
    return false;

}
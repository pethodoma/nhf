#include "fofuggvenyek.h"
#include "struktura.h"
#include <stdio.h>
#include <stdbool.h>
#include "segedfuggvenyek.h"
#include <stdlib.h>
#include <string.h>

void kiir(Esemeny *eleje){
    Esemeny *temp=eleje;
    while(temp!=NULL){
        printf("%d.%d.%d: %s, Itt: %s\n",temp->ev,temp->honap,temp->nap,temp->nev,temp->hely);
        temp=temp->kovetkezo;
    }
}
void rendezveepit(Esemeny **eleje,Esemeny *uj){
    Esemeny *lemarado=NULL;
    Esemeny *mozgo=*eleje;
    while(mozgo!=NULL && rendeznikell(mozgo,uj)) {
        lemarado = mozgo;
        mozgo = mozgo->kovetkezo;
    }
    if(lemarado==NULL){
        uj->kovetkezo=*eleje;
        *eleje=uj;
    }
    else{
        lemarado->kovetkezo=uj;
        uj->kovetkezo=mozgo;
    }
}
Esemeny *letrehoz(){
    Esemeny *ujesemeny=(Esemeny*)malloc(sizeof(Esemeny));
    printf("Ev,honap,nap (szokozzel elvalaszva): ");

    scanf("%d %02d %02d%*c",&ujesemeny->ev,&ujesemeny->honap,&ujesemeny->nap);
    if(ujesemeny->honap<13 && ujesemeny->nap<32 && ujesemeny->honap>0 && ujesemeny->nap>0){
        printf("Esemeny neve: ");

        beolvas(ujesemeny->nev);
        printf("Helyszin: ");
        beolvas(ujesemeny->hely);
        printf("Rovid leiras: ");
        beolvas(ujesemeny->leiras);
        printf("Sikeresen beolvasva: %d.%d.%d: Esemeny neve: %s Helye: %s Leiras: %s\n",ujesemeny->ev,ujesemeny->honap,ujesemeny->nap,ujesemeny->nev,ujesemeny->hely,ujesemeny->leiras);
        ujesemeny->kovetkezo=NULL;
        return ujesemeny;}
    else{
        printf("Helytelen formatum, probald ujra.\n");
        letrehoz();
    }
}

Esemeny *keres(Esemeny *eleje){
    char kereses[20];
    bool van=false;
    printf("Esemeny neve: ");
    Esemeny *temp=eleje;
    beolvas(kereses);
    if(vane(temp,kereses)){
        while(temp!=NULL || van!=true){
            if(strcmp(kereses,temp->nev)==0){
                printf("Van talalat:\n");
                van=true;
                printf("%d.%d.%d: %s (%s) %s\n",temp->ev,temp->honap,temp->nap,temp->nev,temp->hely,temp->leiras);
                return temp;
            }
            temp=temp->kovetkezo;

        }
    }
    else{
        printf("Nincs talalat.\n");
        return NULL;
    }
}

Esemeny *modosit(Esemeny *e){
    if(e==NULL)
        printf("Hiba lepett fel.\n");
    else{
        printf("Mit szeretnel modositani?\n");
        printf("1.Datum\n2.Nev\n3.Hely\n");
        int valasztas;
        int ujev,ujho,ujnap;
        char ujnev[20],ujhely[20];
        scanf("%d%*c",&valasztas);
        switch(valasztas){
            case 1:

                printf("Uj datum: ");
                scanf("%d %d %d",&ujev,&ujho,&ujnap);
                e->ev=ujev;
                e->honap=ujho;
                e->nap=ujnap;
                printf("Sikeres valtoztatas.");

                break;
            case 2:

                printf("Uj nev: ");
                beolvas(ujnev);
                strcpy(e->nev,ujnev);
                printf("Sikeres valtoztatas.");
                break;
            case 3:
                printf("Uj hely: ");
                beolvas(ujhely);
                strcpy(e->hely,ujhely);
                printf("Sikeres valtoztatas.");
                break;
        }
    }
    return e;
}
void honaplista(Esemeny *eleje) {
    Esemeny *mozgo = eleje;
    int evbe, honapbe;
    printf("Ev es honap: ");
    scanf("%d %d", &evbe, &honapbe);
    if(vaneho(eleje,evbe,honapbe)) {
        while (mozgo != NULL) {
            if (mozgo->ev == evbe && mozgo->honap == honapbe) {
                printf("%d.%d.%d: %s, Itt: %s\n", mozgo->ev, mozgo->honap, mozgo->nap, mozgo->nev, mozgo->hely);

            }
            mozgo = mozgo->kovetkezo;
        }
    }
    else
        printf("Nincs talalato esemeny.");
}
void naplista(Esemeny *eleje){
    Esemeny *mozgo=eleje;
    int evbe,honapbe,napbe;
    printf("Ev,honap,nap: ");
    scanf("%d %d %d",&evbe,&honapbe,&napbe);
    if(vanenap(eleje,evbe,honapbe,napbe)) {
        while (mozgo != NULL) {
            if (mozgo->ev == evbe && mozgo->honap == honapbe && mozgo->nap == napbe)
                printf("%d.%d.%d: %s, Itt: %s\n", mozgo->ev, mozgo->honap, mozgo->nap, mozgo->nev, mozgo->hely);
            mozgo = mozgo->kovetkezo;
        }
    }
    else
        printf("Nincs talalhato esemeny.");
}
Esemeny* torol(Esemeny *eleje,Esemeny *e){
    Esemeny *lemarado=NULL;
    Esemeny *mozgo=eleje;

    while(mozgo!= NULL){
        if(egyezik(mozgo,e))
            break;
        lemarado=mozgo;
        mozgo=mozgo->kovetkezo;
    }
    if(lemarado==NULL){
        Esemeny *uj= mozgo->kovetkezo;
        free(mozgo);
        return uj;
    }
    else{
        lemarado->kovetkezo=mozgo->kovetkezo;
        free(mozgo);


    }
    return eleje;
}
#include "struktura.h"
#include "fajlkez.h"
#include <stdlib.h>
#include <stdio.h>
/*cmd-bol inditva masik mappaban keresi/hozza letre a filet ha nem adunk eleresi utat*/

void fajlbair(Esemeny *eleje){
    FILE *f;
    char filenev[30];
    printf("Hasznalni kivant file: ");
    scanf("%s",filenev);
    f=fopen(filenev,"a");
    Esemeny *mozgo=eleje;
    if(f==NULL){
        perror("Sikertelen.\n");

    }
    else{
        while(mozgo!=NULL){
            fprintf(f,"%d %d %d: %s (%s) %s\n",mozgo->ev,mozgo->honap,mozgo->nap,mozgo->nev,mozgo->hely,mozgo->leiras);
            mozgo=mozgo->kovetkezo;
        }
    printf("Sikeres mentes.");
    }
    fclose(f);

}

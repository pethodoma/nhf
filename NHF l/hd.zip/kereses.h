#include "struktura.h"
#include <stdbool.h>
#ifndef NHF_L_KERESES_H
#define NHF_L_KERESES_H
bool vane(Esemeny *eleje,char *szoveg);
Esemeny *modosit(Esemeny *e);
Esemeny *keres(Esemeny *eleje);
#endif //NHF_L_KERESES_H

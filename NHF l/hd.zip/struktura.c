#include "struktura.h"

#include "struktura.h"
#ifndef NHF_L_FOFUGGVENYEK_H
#define NHF_L_FOFUGGVENYEK_H
void kiir(Esemeny *eleje);
void rendezveepit(Esemeny **eleje,Esemeny *uj);
Esemeny *letrehoz();
Esemeny *keres(Esemeny *eleje);
Esemeny *modosit(Esemeny *e);
void honaplista(Esemeny *eleje);
void naplista(Esemeny *eleje);
Esemeny* torol(Esemeny *eleje,Esemeny *e);
void sikerestorles();
void felszabadit(Esemeny *eleje);
void menu();
#endif //NHF_L_FOFUGGVENYEK_H
